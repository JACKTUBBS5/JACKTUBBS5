controlROCregData <-
function(  
   cat.cont = NULL,                       
   card.cont = 50                         
   )
   list(cat.cont = cat.cont, card.cont = card.cont)

